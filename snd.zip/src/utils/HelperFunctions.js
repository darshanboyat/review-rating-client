export const getUser = () =>{
    return localStorage.getItem("user");
}