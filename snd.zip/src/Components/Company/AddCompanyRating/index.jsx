import React from 'react'

const Index = () => {
  return (
    <>
        /company/company_review
    </>
  )
}

export default Index